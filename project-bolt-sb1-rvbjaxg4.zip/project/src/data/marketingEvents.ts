export interface MarketingEvent {
  name: string;
  description: string;
  category: 'holiday' | 'seasonal' | 'awareness' | 'ecommerce' | 'social';
}

export const marketingEvents: Record<string, MarketingEvent[]> = {
  // January
  '1-1': [
    {
      name: 'New Year\'s Day',
      description: 'Fresh starts, resolutions, and new beginnings',
      category: 'holiday'
    }
  ],
  '1-15': [
    {
      name: 'Martin Luther King Jr. Day',
      description: 'Civil rights, equality, and social justice themes',
      category: 'awareness'
    }
  ],
  '1-20': [
    {
      name: 'Blue Monday',
      description: 'Most depressing day of the year - wellness focus',
      category: 'awareness'
    }
  ],

  // February
  '2-2': [
    {
      name: 'Groundhog Day',
      description: 'Tradition, weather predictions, and fun campaigns',
      category: 'holiday'
    }
  ],
  '2-14': [
    {
      name: 'Valentine\'s Day',
      description: 'Love, relationships, gifts, and romantic themes',
      category: 'holiday'
    }
  ],
  '2-15': [
    {
      name: 'Presidents\' Day',
      description: 'American history, leadership, and patriotic themes',
      category: 'holiday'
    }
  ],

  // March
  '3-8': [
    {
      name: 'International Women\'s Day',
      description: 'Women\'s rights, empowerment, and gender equality',
      category: 'awareness'
    }
  ],
  '3-17': [
    {
      name: 'St. Patrick\'s Day',
      description: 'Irish culture, green themes, and celebrations',
      category: 'holiday'
    }
  ],
  '3-20': [
    {
      name: 'Spring Equinox',
      description: 'Spring season begins, renewal and growth themes',
      category: 'seasonal'
    }
  ],

  // April
  '4-1': [
    {
      name: 'April Fool\'s Day',
      description: 'Humor, pranks, and playful marketing campaigns',
      category: 'holiday'
    }
  ],
  '4-22': [
    {
      name: 'Earth Day',
      description: 'Environmental awareness, sustainability, and green initiatives',
      category: 'awareness'
    }
  ],

  // May
  '5-1': [
    {
      name: 'May Day',
      description: 'Labor rights, spring celebrations, and worker appreciation',
      category: 'awareness'
    }
  ],
  '5-9': [
    {
      name: 'Mother\'s Day',
      description: 'Celebrating mothers, family bonds, and appreciation',
      category: 'holiday'
    }
  ],
  '5-31': [
    {
      name: 'Memorial Day',
      description: 'Honoring military service members, patriotic themes',
      category: 'holiday'
    }
  ],

  // June
  '6-19': [
    {
      name: 'Father\'s Day',
      description: 'Celebrating fathers, family bonds, and appreciation',
      category: 'holiday'
    }
  ],
  '6-21': [
    {
      name: 'Summer Solstice',
      description: 'Longest day of the year, summer themes',
      category: 'seasonal'
    }
  ],

  // July
  '7-4': [
    {
      name: 'Independence Day',
      description: 'American patriotism, freedom, and national celebration',
      category: 'holiday'
    }
  ],

  // August
  '8-15': [
    {
      name: 'Back to School Season',
      description: 'Education, students, parents, and school supplies',
      category: 'seasonal'
    }
  ],

  // September
  '9-6': [
    {
      name: 'Labor Day',
      description: 'End of summer, back to work, and worker appreciation',
      category: 'holiday'
    }
  ],
  '9-22': [
    {
      name: 'Fall Equinox',
      description: 'Autumn begins, harvest themes, and seasonal changes',
      category: 'seasonal'
    }
  ],

  // October
  '10-9': [
    {
      name: 'Columbus Day',
      description: 'Exploration, discovery, and historical themes',
      category: 'holiday'
    }
  ],
  '10-31': [
    {
      name: 'Halloween',
      description: 'Costumes, candy, spooky themes, and fun celebrations',
      category: 'holiday'
    }
  ],

  // November
  '11-11': [
    {
      name: 'Veterans Day',
      description: 'Honoring military veterans and patriotic themes',
      category: 'holiday'
    }
  ],
  '11-25': [
    {
      name: 'Thanksgiving',
      description: 'Gratitude, family gatherings, and harvest themes',
      category: 'holiday'
    }
  ],
  '11-26': [
    {
      name: 'Black Friday',
      description: 'Major shopping day, deals, and retail promotions',
      category: 'ecommerce'
    }
  ],
  '11-29': [
    {
      name: 'Cyber Monday',
      description: 'Online shopping deals and e-commerce promotions',
      category: 'ecommerce'
    }
  ],

  // December
  '12-21': [
    {
      name: 'Winter Solstice',
      description: 'Shortest day of the year, winter themes',
      category: 'seasonal'
    }
  ],
  '12-25': [
    {
      name: 'Christmas',
      description: 'Holiday celebrations, gifts, family, and festive themes',
      category: 'holiday'
    }
  ],
  '12-31': [
    {
      name: 'New Year\'s Eve',
      description: 'Year-end celebrations, reflections, and new beginnings',
      category: 'holiday'
    }
  ]
};