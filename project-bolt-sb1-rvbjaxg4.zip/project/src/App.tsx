import React, { useState } from 'react';
import { Calendar, Sparkles, Crown, Menu, X, User, LogOut } from 'lucide-react';
import MarketingCalendar from './components/MarketingCalendar';
import Header from './components/Header';
import Hero from './components/Hero';
import PricingModal from './components/PricingModal';
import AuthModal from './components/AuthModal';
import PaymentModal from './components/PaymentModal';
import { useAuth } from './hooks/useAuth';

function App() {
  const [currentView, setCurrentView] = useState<'home' | 'calendar'>('home');
  const [showPricing, setShowPricing] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  
  const { user, loading, signOut, isPremium } = useAuth();

  const handleUpgrade = () => {
    if (!user) {
      setAuthMode('signin');
      setShowAuth(true);
    } else {
      setShowPayment(true);
    }
  };

  const handleAuthSuccess = () => {
    setShowAuth(false);
    if (currentView === 'home') {
      setCurrentView('calendar');
    }
  };

  const handlePaymentSuccess = () => {
    setShowPayment(false);
    // 刷新用户状态
    window.location.reload();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">加载中...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-lg border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Calendar className="h-8 w-8 text-blue-600" />
              <span className="text-xl font-bold text-gray-900">MarketingAI</span>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-6">
              <button
                onClick={() => setCurrentView('home')}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  currentView === 'home' 
                    ? 'text-blue-600 bg-blue-50' 
                    : 'text-gray-700 hover:text-blue-600'
                }`}
              >
                首页
              </button>
              <button
                onClick={() => setCurrentView('calendar')}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  currentView === 'calendar' 
                    ? 'text-blue-600 bg-blue-50' 
                    : 'text-gray-700 hover:text-blue-600'
                }`}
              >
                营销日历
              </button>
            </nav>

            {/* User Actions */}
            <div className="hidden md:flex items-center space-x-4">
              {user ? (
                <div className="flex items-center space-x-4">
                  {isPremium ? (
                    <div className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-blue-600 text-white rounded-full">
                      <Crown className="h-4 w-4" />
                      <span className="text-sm font-medium">Premium</span>
                    </div>
                  ) : (
                    <button
                      onClick={handleUpgrade}
                      className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-full hover:from-purple-700 hover:to-blue-700 transition-all duration-200 transform hover:scale-105"
                    >
                      <Crown className="h-4 w-4" />
                      <span className="text-sm font-medium">升级</span>
                    </button>
                  )}
                  
                  <div className="flex items-center space-x-2 text-gray-700">
                    <User className="h-4 w-4" />
                    <span className="text-sm">{user.email}</span>
                  </div>
                  
                  <button
                    onClick={signOut}
                    className="p-2 text-gray-500 hover:text-gray-700 transition-colors"
                    title="退出登录"
                  >
                    <LogOut className="h-4 w-4" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => {
                      setAuthMode('signin');
                      setShowAuth(true);
                    }}
                    className="px-4 py-2 text-gray-700 hover:text-blue-600 transition-colors"
                  >
                    登录
                  </button>
                  <button
                    onClick={() => {
                      setAuthMode('signup');
                      setShowAuth(true);
                    }}
                    className="px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all"
                  >
                    注册
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>
      
      {currentView === 'home' ? (
        <Hero onGetStarted={() => setCurrentView('calendar')} />
      ) : (
        <MarketingCalendar 
          isPremium={isPremium}
          onUpgrade={handleUpgrade}
          user={user}
        />
      )}

      {/* Modals */}
      <AuthModal
        isOpen={showAuth}
        onClose={() => setShowAuth(false)}
        mode={authMode}
        onModeChange={setAuthMode}
      />

      <PaymentModal
        isOpen={showPayment}
        onClose={() => setShowPayment(false)}
        onSuccess={handlePaymentSuccess}
      />

      {showPricing && (
        <PricingModal 
          onClose={() => setShowPricing(false)}
          onSubscribe={handleUpgrade}
        />
      )}
    </div>
  );
}

export default App;