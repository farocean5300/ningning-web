const basicSuggestions: Record<string, string> = {
  "New Year's Day": "Create 'New Year, New You' campaigns focusing on fresh starts and goal-setting. Promote fitness, productivity, or self-improvement products.",
  "Valentine's Day": "Design romantic campaigns with special offers for couples. Focus on gifts, experiences, and emotional connections.",
  "St. Patrick's Day": "Use green themes and Irish-inspired content. Great for food, beverages, and festive promotions.",
  "Earth Day": "Highlight eco-friendly products and sustainable practices. Show your brand's commitment to environmental responsibility.",
  "Mother's Day": "Create heartwarming campaigns celebrating mothers. Promote gifts, experiences, and family-focused products.",
  "Father's Day": "Design campaigns honoring fathers with gift ideas and family activities. Focus on tools, tech, and experiences.",
  "Independence Day": "Use patriotic themes with red, white, and blue. Perfect for summer sales and outdoor activities.",
  "Halloween": "Create spooky, fun campaigns with costume themes. Great for creative content and seasonal products.",
  "Black Friday": "Launch major discount campaigns with urgency. Focus on limited-time offers and exclusive deals.",
  "Cyber Monday": "Emphasize online-exclusive deals and digital promotions. Perfect for e-commerce and tech products.",
  "Christmas": "Create festive campaigns with gift guides and holiday spirit. Focus on family, giving, and celebration.",
  "Back to School Season": "Target students and parents with educational content and school supplies. Focus on preparation and success."
};

const premiumSuggestions: Record<string, string> = {
  "New Year's Day": "🎯 Campaign Strategy: Launch a '365 Days of Change' campaign with weekly challenges. Target health-conscious millennials (25-40) with 68% higher engagement on transformation content. Use video testimonials, progress tracking, and community building. Predicted ROI: 340% with email sequences and social proof.",
  "Valentine's Day": "🎯 Advanced Strategy: Implement a 'Love Languages Marketing' approach targeting couples by communication style. Segment audiences: Gift Givers (luxury items), Quality Time (experiences), Words of Affirmation (personalized messages). Use retargeting ads 14 days before, email sequences, and influencer partnerships. Expected conversion rate: 12.8%.",
  "St. Patrick's Day": "🎯 Premium Insights: Create 'Lucky Finds' limited-edition campaigns. Target Irish-American demographics (12M people) and party enthusiasts. Use geo-targeting near Irish pubs, St. Patrick's Day events. Implement countdown timers, social media contests, and user-generated content with hashtag #LuckyFinds. Predicted engagement: +245%.",
  "Earth Day": "🎯 Strategic Campaign: Launch 'Planet Positive' brand positioning with carbon-neutral shipping, tree planting partnerships, and sustainability reports. Target eco-conscious consumers (73% of millennials). Create educational content series, partner with environmental influencers, and use green certifications. Expected brand lift: +67%.",
  "Mother's Day": "🎯 Advanced Targeting: Segment campaigns by mother types: New Moms (0-2 years), Busy Moms (3-12 years), Empty Nesters (50+). Use emotional storytelling, personalized gift recommendations, and social listening for trending mom topics. Implement Instagram Shopping, Pinterest ads, and YouTube pre-roll. ROI projection: 425%.",
  "Father's Day": "🎯 Data-Driven Strategy: Target based on dad personas: Tech Dads, Outdoor Dads, DIY Dads. Use search intent data, create gift guides with price points, and implement retargeting sequences. Partner with dad bloggers, use LinkedIn ads for professional fathers, and create how-to content. Expected conversion: 18.3%.",
  "Independence Day": "🎯 Patriotic Premium: Create 'Made in USA' product showcases with storytelling about American craftsmanship. Target patriots, military families, and local pride communities. Use video content, American-made certifications, and local business partnerships. Implement geo-targeted ads and community sponsorships. Brand loyalty increase: +89%.",
  "Halloween": "🎯 Spooky Success Strategy: Launch interactive campaigns with AR filters, costume contests, and themed product bundles. Target families with children, young adults (18-34), and party planners. Use TikTok challenges, Instagram Stories polls, and YouTube tutorials. Create limited-edition packaging. Engagement prediction: +312%.",
  "Black Friday": "🎯 Revenue Maximization: Implement tiered pricing strategy with early bird, flash sales, and last-chance offers. Use predictive analytics for inventory, create FOMO with stock counters, and implement cart abandonment sequences. Target bargain hunters, gift shoppers, and brand loyalists with personalized offers. Revenue lift: +267%.",
  "Cyber Monday": "🎯 Digital Domination: Create mobile-first shopping experiences with one-click purchasing, social commerce integration, and influencer exclusive codes. Target digital natives, remote workers, and tech enthusiasts. Use email segmentation, push notifications, and retargeting ads. Optimize for voice search and social shopping. Conversion rate: +34.7%.",
  "Christmas": "🎯 Holiday Mastery: Implement 'Gift Concierge' AI-powered recommendation engine based on recipient personality, interests, and budget. Create advent calendar campaigns, 12 Days of Christmas series, and gift guide segmentation. Use emotional storytelling, family-focused content, and charitable partnerships. Customer lifetime value increase: +156%.",
  "Back to School Season": "🎯 Educational Excellence: Create grade-specific campaigns targeting different student needs: Elementary (parents decide), Middle School (parent-child collaboration), High School (student influence). Use influencer partnerships with student ambassadors, create study tip content, and implement subscription box models. Parent satisfaction score: 94%."
};

export const getAISuggestion = (eventName: string, isPremium: boolean): string => {
  const suggestions = isPremium ? premiumSuggestions : basicSuggestions;
  return suggestions[eventName] || (isPremium 
    ? "🎯 Premium AI Analysis: This date presents unique marketing opportunities. Analyze your target audience demographics, create compelling content themes, implement multi-channel campaigns with personalized messaging, and use data-driven insights to maximize ROI. Expected performance lift: +180-300%."
    : "Consider creating themed content around this date. Look for relevant hashtags, seasonal trends, and audience interests to create engaging campaigns that resonate with your target market.");
};