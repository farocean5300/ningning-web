import React, { useState } from 'react';
import { Calendar, Crown, Menu, X } from 'lucide-react';

interface HeaderProps {
  currentView: 'home' | 'calendar';
  setCurrentView: (view: 'home' | 'calendar') => void;
  isPremium: boolean;
  onUpgrade: () => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, setCurrentView, isPremium, onUpgrade }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="bg-white/80 backdrop-blur-lg border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-2">
            <Calendar className="h-8 w-8 text-blue-600" />
            <span className="text-xl font-bold text-gray-900">MarketingAI</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <button
              onClick={() => setCurrentView('home')}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                currentView === 'home' 
                  ? 'text-blue-600 bg-blue-50' 
                  : 'text-gray-700 hover:text-blue-600'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => setCurrentView('calendar')}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                currentView === 'calendar' 
                  ? 'text-blue-600 bg-blue-50' 
                  : 'text-gray-700 hover:text-blue-600'
              }`}
            >
              Calendar
            </button>
          </nav>

          {/* Premium Badge / Upgrade Button */}
          <div className="hidden md:flex items-center">
            {isPremium ? (
              <div className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-blue-600 text-white rounded-full">
                <Crown className="h-4 w-4" />
                <span className="text-sm font-medium">Premium</span>
              </div>
            ) : (
              <button
                onClick={onUpgrade}
                className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-full hover:from-purple-700 hover:to-blue-700 transition-all duration-200 transform hover:scale-105"
              >
                <Crown className="h-4 w-4" />
                <span className="text-sm font-medium">Upgrade</span>
              </button>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-md text-gray-700 hover:text-blue-600 hover:bg-gray-100"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200">
          <div className="px-4 py-2 space-y-2">
            <button
              onClick={() => {
                setCurrentView('home');
                setMobileMenuOpen(false);
              }}
              className={`block w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
                currentView === 'home' 
                  ? 'text-blue-600 bg-blue-50' 
                  : 'text-gray-700'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => {
                setCurrentView('calendar');
                setMobileMenuOpen(false);
              }}
              className={`block w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
                currentView === 'calendar' 
                  ? 'text-blue-600 bg-blue-50' 
                  : 'text-gray-700'
              }`}
            >
              Calendar
            </button>
            <div className="pt-2 border-t border-gray-200">
              {isPremium ? (
                <div className="flex items-center justify-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-blue-600 text-white rounded-full">
                  <Crown className="h-4 w-4" />
                  <span className="text-sm font-medium">Premium</span>
                </div>
              ) : (
                <button
                  onClick={() => {
                    onUpgrade();
                    setMobileMenuOpen(false);
                  }}
                  className="flex items-center justify-center space-x-2 w-full px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-full"
                >
                  <Crown className="h-4 w-4" />
                  <span className="text-sm font-medium">Upgrade</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;