import React, { useState } from 'react'
import { X, Crown, Check, CreditCard } from 'lucide-react'

interface PaymentModalProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
}

const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onSuccess, onClose }) => {
  const [loading, setLoading] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState<'stripe' | 'alipay'>('stripe')

  if (!isOpen) return null

  const handlePayment = async () => {
    setLoading(true)
    
    try {
      if (paymentMethod === 'stripe') {
        // Stripe 支付流程
        const response = await fetch('/api/create-checkout-session', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            priceId: 'price_premium_monthly', // Stripe 价格 ID
            successUrl: window.location.origin + '/success',
            cancelUrl: window.location.origin + '/cancel',
          }),
        })
        
        const { url } = await response.json()
        window.location.href = url
      } else {
        // 支付宝支付流程（需要后端支持）
        const response = await fetch('/api/alipay-payment', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            amount: 29,
            subject: 'MarketingAI Premium 订阅',
          }),
        })
        
        const { payUrl } = await response.json()
        window.open(payUrl, '_blank')
      }
    } catch (error) {
      console.error('支付失败:', error)
      alert('支付失败，请重试')
    } finally {
      setLoading(false)
    }
  }

  // 模拟支付成功（开发阶段使用）
  const handleMockPayment = () => {
    setLoading(true)
    setTimeout(() => {
      onSuccess()
      onClose()
      setLoading(false)
      alert('支付成功！您已升级为Premium用户')
    }, 2000)
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">升级到Premium</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-6 w-6 text-gray-500" />
          </button>
        </div>

        {/* 价格展示 */}
        <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-2xl p-6 mb-6">
          <div className="text-center">
            <Crown className="h-12 w-12 text-purple-600 mx-auto mb-4" />
            <div className="text-3xl font-bold text-gray-900 mb-2">¥29</div>
            <div className="text-gray-600 mb-4">每月</div>
            
            <ul className="space-y-2 text-sm text-left">
              <li className="flex items-center space-x-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>高级AI营销策略</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>详细受众分析</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>营销模板库</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>数据分析报告</span>
              </li>
            </ul>
          </div>
        </div>

        {/* 支付方式选择 */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-4">选择支付方式</h3>
          <div className="space-y-3">
            <label className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                name="payment"
                value="stripe"
                checked={paymentMethod === 'stripe'}
                onChange={(e) => setPaymentMethod(e.target.value as 'stripe')}
                className="mr-3"
              />
              <CreditCard className="h-5 w-5 mr-2 text-blue-600" />
              <span>信用卡支付 (Stripe)</span>
            </label>
            
            <label className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                name="payment"
                value="alipay"
                checked={paymentMethod === 'alipay'}
                onChange={(e) => setPaymentMethod(e.target.value as 'alipay')}
                className="mr-3"
              />
              <div className="w-5 h-5 mr-2 bg-blue-500 rounded text-white text-xs flex items-center justify-center">
                支
              </div>
              <span>支付宝</span>
            </label>
          </div>
        </div>

        {/* 支付按钮 */}
        <div className="space-y-3">
          <button
            onClick={handlePayment}
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg font-semibold hover:from-purple-700 hover:to-blue-700 transition-all disabled:opacity-50"
          >
            {loading ? '处理中...' : '立即支付'}
          </button>
          
          {/* 开发阶段的模拟支付按钮 */}
          <button
            onClick={handleMockPayment}
            disabled={loading}
            className="w-full py-3 border-2 border-gray-300 text-gray-700 rounded-lg font-semibold hover:border-purple-600 hover:text-purple-600 transition-all"
          >
            模拟支付成功 (开发测试)
          </button>
        </div>

        <div className="mt-4 text-center text-xs text-gray-500">
          <p>安全支付 • 随时取消 • 30天退款保证</p>
        </div>
      </div>
    </div>
  )
}

export default PaymentModal