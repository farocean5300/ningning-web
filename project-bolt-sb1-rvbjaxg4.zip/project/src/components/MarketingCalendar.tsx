import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Sparkles, Lock, Crown, User } from 'lucide-react';
import { marketingEvents } from '../data/marketingEvents';
import { getAISuggestion } from '../utils/aiSuggestions';

interface MarketingCalendarProps {
  isPremium: boolean;
  onUpgrade: () => void;
  user: any;
}

const MarketingCalendar: React.FC<MarketingCalendarProps> = ({ isPremium, onUpgrade, user }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();
  
  const monthNames = [
    '一月', '二月', '三月', '四月', '五月', '六月',
    '七月', '八月', '九月', '十月', '十一月', '十二月'
  ];

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
    setSelectedDate(null);
  };

  const getEventsForDate = (day: number) => {
    const dateKey = `${currentDate.getMonth() + 1}-${day}`;
    return marketingEvents[dateKey] || [];
  };

  const handleDateClick = (day: number) => {
    const clickedDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    setSelectedDate(clickedDate);
  };

  const renderCalendarDays = () => {
    const days = [];
    
    // Empty cells for days before the first day of the month
    for (let i = 0; i < firstDayOfMonth; i++) {
      days.push(<div key={`empty-${i}`} className="h-24"></div>);
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const events = getEventsForDate(day);
      const hasEvents = events.length > 0;
      const isSelected = selectedDate && selectedDate.getDate() === day;

      days.push(
        <div
          key={day}
          onClick={() => handleDateClick(day)}
          className={`h-24 p-2 border border-gray-200 cursor-pointer transition-all duration-200 hover:bg-blue-50 ${
            isSelected ? 'bg-blue-100 border-blue-300' : ''
          } ${hasEvents ? 'bg-gradient-to-br from-purple-50 to-blue-50' : ''}`}
        >
          <div className="flex justify-between items-start h-full">
            <span className={`text-sm font-medium ${hasEvents ? 'text-purple-700' : 'text-gray-700'}`}>
              {day}
            </span>
            {hasEvents && (
              <div className="flex flex-col space-y-1">
                {events.slice(0, 2).map((event, index) => (
                  <div
                    key={index}
                    className="text-xs px-2 py-1 bg-purple-100 text-purple-800 rounded-full truncate max-w-16"
                    title={event.name}
                  >
                    {event.name.length > 8 ? event.name.substring(0, 8) + '...' : event.name}
                  </div>
                ))}
                {events.length > 2 && (
                  <div className="text-xs text-purple-600 font-medium">
                    +{events.length - 2} 更多
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      );
    }

    return days;
  };

  // 如果用户未登录，显示登录提示
  if (!user) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <User className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-4">请先登录</h2>
          <p className="text-gray-600 mb-8">登录后即可使用营销日历功能</p>
          <button
            onClick={onUpgrade}
            className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all"
          >
            立即登录
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Calendar */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200">
            {/* Calendar Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-gray-900">
                {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
              </h2>
              <div className="flex space-x-2">
                <button
                  onClick={() => navigateMonth('prev')}
                  className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <ChevronLeft className="h-5 w-5 text-gray-600" />
                </button>
                <button
                  onClick={() => navigateMonth('next')}
                  className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <ChevronRight className="h-5 w-5 text-gray-600" />
                </button>
              </div>
            </div>

            {/* Calendar Grid */}
            <div className="p-4">
              {/* Day Headers */}
              <div className="grid grid-cols-7 gap-1 mb-2">
                {['日', '一', '二', '三', '四', '五', '六'].map(day => (
                  <div key={day} className="text-center text-sm font-medium text-gray-500 py-2">
                    {day}
                  </div>
                ))}
              </div>
              
              {/* Calendar Days */}
              <div className="grid grid-cols-7 gap-1">
                {renderCalendarDays()}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* User Info */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center space-x-3 mb-4">
              <User className="h-8 w-8 text-blue-600" />
              <div>
                <h3 className="font-semibold text-gray-900">{user.email}</h3>
                <p className="text-sm text-gray-600">
                  {isPremium ? 'Premium 用户' : '免费用户'}
                </p>
              </div>
            </div>
            
            {isPremium && (
              <div className="flex items-center space-x-2 px-3 py-2 bg-gradient-to-r from-purple-100 to-blue-100 rounded-lg">
                <Crown className="h-4 w-4 text-purple-600" />
                <span className="text-sm font-medium text-purple-900">Premium 会员</span>
              </div>
            )}
          </div>

          {/* Selected Date Info */}
          {selectedDate && (
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                {selectedDate.toLocaleDateString('zh-CN', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </h3>

              {/* Events for Selected Date */}
              <div className="space-y-4">
                {getEventsForDate(selectedDate.getDate()).map((event, index) => (
                  <div key={index} className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl">
                    <h4 className="font-semibold text-purple-900 mb-2">{event.name}</h4>
                    <p className="text-sm text-purple-700 mb-3">{event.description}</p>
                    
                    {/* Basic AI Suggestion */}
                    <div className="bg-white rounded-lg p-3 border border-purple-200">
                      <div className="flex items-center space-x-2 mb-2">
                        <Sparkles className="h-4 w-4 text-blue-600" />
                        <span className="text-sm font-medium text-gray-900">AI 建议</span>
                      </div>
                      <p className="text-sm text-gray-700">
                        {getAISuggestion(event.name, false)}
                      </p>
                    </div>

                    {/* Premium AI Suggestions */}
                    {!isPremium && (
                      <div className="mt-3 p-3 bg-gradient-to-r from-gray-100 to-gray-50 rounded-lg border-2 border-dashed border-gray-300">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Lock className="h-4 w-4 text-gray-500" />
                            <span className="text-sm font-medium text-gray-700">高级 AI 洞察</span>
                          </div>
                          <button
                            onClick={onUpgrade}
                            className="px-3 py-1 bg-gradient-to-r from-purple-600 to-blue-600 text-white text-xs rounded-full hover:from-purple-700 hover:to-blue-700 transition-all"
                          >
                            解锁
                          </button>
                        </div>
                        <p className="text-xs text-gray-600 mt-2">
                          • 详细营销策略 • 目标受众分析 • 内容模板 • 效果预测
                        </p>
                      </div>
                    )}

                    {/* Premium Content */}
                    {isPremium && (
                      <div className="mt-3 p-3 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border border-purple-200">
                        <div className="flex items-center space-x-2 mb-2">
                          <Crown className="h-4 w-4 text-purple-600" />
                          <span className="text-sm font-medium text-purple-900">高级 AI 洞察</span>
                        </div>
                        <p className="text-sm text-purple-700">
                          {getAISuggestion(event.name, true)}
                        </p>
                      </div>
                    )}
                  </div>
                ))}

                {getEventsForDate(selectedDate.getDate()).length === 0 && (
                  <div className="text-center py-8">
                    <div className="text-gray-400 mb-2">今天没有特殊营销节点</div>
                    <p className="text-sm text-gray-600">
                      查看其他日期或探索通用营销机会！
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Upgrade CTA */}
          {!isPremium && (
            <div className="bg-gradient-to-br from-purple-600 to-blue-600 text-white rounded-2xl p-6">
              <div className="flex items-center space-x-2 mb-3">
                <Crown className="h-6 w-6" />
                <h3 className="text-lg font-semibold">升级到 Premium</h3>
              </div>
              <ul className="space-y-2 text-sm mb-4">
                <li>• 高级 AI 营销策略</li>
                <li>• 详细受众洞察</li>
                <li>• 即用内容模板</li>
                <li>• 效果预测分析</li>
              </ul>
              <button
                onClick={onUpgrade}
                className="w-full py-3 bg-white text-purple-600 rounded-xl font-semibold hover:bg-gray-100 transition-colors"
              >
                立即升级
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MarketingCalendar;