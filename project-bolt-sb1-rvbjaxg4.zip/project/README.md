# MarketingAI - AI营销日历网站

一个基于AI的营销日历网站，帮助营销人员发现营销机会并获得AI驱动的营销建议。

## 功能特性

- 📅 **智能营销日历** - 显示重要营销节点和节日
- 🤖 **AI营销建议** - 基于日期生成个性化营销创意
- 👑 **分层订阅** - 免费基础功能 + Premium高级功能
- 🔐 **用户系统** - 完整的注册、登录、订阅管理
- 💳 **支付集成** - 支持Stripe和支付宝
- 📱 **响应式设计** - 完美适配所有设备

## 技术栈

- **前端**: React 18 + TypeScript + Tailwind CSS
- **后端**: Supabase (数据库 + 认证 + API)
- **支付**: Stripe + 支付宝
- **部署**: Netlify (前端) + Supabase (后端)
- **图标**: Lucide React

## 快速开始

### 1. 克隆项目
```bash
git clone <your-repo-url>
cd marketing-ai-calendar
npm install
```

### 2. 环境配置
复制 `.env.example` 为 `.env` 并填入配置：

```bash
cp .env.example .env
```

### 3. Supabase 设置

1. 访问 [Supabase](https://supabase.com) 创建新项目
2. 在项目设置中获取 URL 和 anon key
3. 运行数据库迁移：
   ```sql
   -- 在 Supabase SQL 编辑器中运行 supabase/migrations/001_initial_schema.sql
   ```

### 4. 启动开发服务器
```bash
npm run dev
```

## 部署指南

### 方案一：Netlify + Supabase (推荐)

**优势**: 免费额度大，配置简单，适合新手

1. **部署前端到 Netlify**
   ```bash
   npm run build
   ```
   - 将 `dist` 文件夹拖拽到 Netlify
   - 或连接 GitHub 自动部署

2. **配置环境变量**
   - 在 Netlify 项目设置中添加环境变量
   - 添加 `VITE_SUPABASE_URL` 和 `VITE_SUPABASE_ANON_KEY`

3. **成本**: 
   - Netlify: 免费 (100GB 带宽/月)
   - Supabase: 免费 (50MB 数据库 + 50,000 月活用户)

### 方案二：Vercel + Supabase

1. **部署到 Vercel**
   ```bash
   npx vercel --prod
   ```

2. **配置环境变量**
   ```bash
   vercel env add VITE_SUPABASE_URL
   vercel env add VITE_SUPABASE_ANON_KEY
   ```

## 支付集成

### Stripe 集成

1. **注册 Stripe 账户**
   - 访问 [Stripe Dashboard](https://dashboard.stripe.com)
   - 获取 Publishable Key 和 Secret Key

2. **创建产品和价格**
   ```bash
   # 在 Stripe Dashboard 中创建：
   # 产品名称: MarketingAI Premium
   # 价格: $29/月 或 ¥29/月
   # 获取 Price ID
   ```

3. **配置 Webhook**
   - 端点 URL: `https://your-domain.com/api/stripe-webhook`
   - 监听事件: `checkout.session.completed`, `invoice.payment_succeeded`

### 支付宝集成

1. **申请支付宝开发者账户**
   - 访问 [支付宝开放平台](https://open.alipay.com)
   - 创建应用并获取 App ID

2. **配置密钥**
   - 生成 RSA 密钥对
   - 上传公钥到支付宝后台

## 变现策略

### 定价策略
- **免费版**: 基础日历 + 简单AI建议
- **Premium版**: ¥29/月
  - 高级AI策略分析
  - 详细受众洞察  
  - 营销模板库
  - 数据分析报告

### 转化优化
1. **免费试用**: 7天Premium免费体验
2. **限制策略**: 免费用户每日AI建议次数限制
3. **价值展示**: 对比免费vs付费功能差异
4. **社交证明**: 显示用户数量和成功案例

### 收入预测
- 目标用户: 1000个免费用户
- 转化率: 5% (50个付费用户)
- 月收入: 50 × ¥29 = ¥1,450
- 年收入: ¥17,400

## 用户管理

### 认证流程
1. **注册**: 邮箱 + 密码
2. **验证**: 邮箱验证链接 (可选)
3. **登录**: 自动保持登录状态
4. **权限**: 基于订阅状态控制功能访问

### 订阅管理
```sql
-- 检查用户Premium状态
SELECT is_premium, premium_expires_at 
FROM profiles 
WHERE id = auth.uid();

-- 升级用户为Premium
UPDATE profiles 
SET is_premium = true, 
    premium_expires_at = now() + interval '1 month'
WHERE id = auth.uid();
```

## 开发指南

### 项目结构
```
src/
├── components/          # React 组件
│   ├── AuthModal.tsx   # 登录/注册弹窗
│   ├── PaymentModal.tsx # 支付弹窗
│   └── MarketingCalendar.tsx # 主日历组件
├── hooks/              # 自定义 Hooks
│   └── useAuth.ts      # 认证状态管理
├── lib/                # 工具库
│   └── supabase.ts     # Supabase 客户端
├── data/               # 静态数据
│   └── marketingEvents.ts # 营销事件数据
└── utils/              # 工具函数
    └── aiSuggestions.ts # AI建议生成
```

### 添加新功能

1. **新增营销事件**
   ```typescript
   // src/data/marketingEvents.ts
   '12-12': [
     {
       name: '双十二购物节',
       description: '年末购物狂欢',
       category: 'ecommerce'
     }
   ]
   ```

2. **自定义AI建议**
   ```typescript
   // src/utils/aiSuggestions.ts
   const premiumSuggestions = {
     "双十二购物节": "🎯 高级策略: 年末清仓 + 新年预热..."
   }
   ```

## 常见问题

### Q: 如何修改定价？
A: 修改 `src/components/PaymentModal.tsx` 中的价格显示，同时更新 Stripe 产品价格。

### Q: 如何添加新的支付方式？
A: 在 `PaymentModal.tsx` 中添加新的支付选项，并实现对应的支付逻辑。

### Q: 如何自定义AI建议？
A: 编辑 `src/utils/aiSuggestions.ts`，添加或修改建议内容。

### Q: 数据库迁移失败怎么办？
A: 检查 Supabase 项目权限，确保 SQL 语法正确，可以分步执行迁移文件。

## 许可证

MIT License - 详见 LICENSE 文件

## 支持

如有问题，请提交 Issue 或联系开发者。

---

**快速上线，开始变现！** 🚀